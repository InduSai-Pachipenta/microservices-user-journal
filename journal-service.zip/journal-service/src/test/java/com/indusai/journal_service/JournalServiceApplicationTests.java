package com.indusai.journal_service;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JournalServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
